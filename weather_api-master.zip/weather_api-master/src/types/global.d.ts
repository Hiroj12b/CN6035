interface WeatherData {
  temperature: number;
  humidity: number;
  wind: number;
  rain: number;
}
